# image_processing

## Description.
the package image_processing is used to:
    Processing:
        - Histograma
        - Structural similaruty
        - Resize image
    Utils
        - Read image
        - Save image
        - Plot image
        - Plot result
        - Plot Hitogram

## installation 

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

'''bash
pip install image_processing
'''

## Author
Willdeglan SQL-Dicas

## License
[MIT](https://choosealicense.com/licenses/mit/)
